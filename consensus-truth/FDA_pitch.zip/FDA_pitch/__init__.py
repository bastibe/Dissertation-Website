import jbof
dataset = jbof.DataSet(jbof.Path(__file__).parent)
